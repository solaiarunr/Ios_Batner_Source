//
//  CustomPage.swift
//  Joysale_Swift
//
//  Created by MAC pro 2.9Ghz on 02/12/20.
//  Copyright © 2020 Hitasoft. All rights reserved.
//

import UIKit
import DropDown
import Mapbox
import MapboxGeocoder
import GooglePlaces
import GoogleMaps

protocol customLocationDelegate {
    func locationAct(city: String, state: String, country: String, countryCode: String,lat: String, long: String, location: String)
}

class MapViewController: UIViewController {
    @IBOutlet weak var markerButton: UIButton!
    @IBOutlet weak var currentLocationButton: UIButton!
    @IBOutlet weak var currentLocationView: UIView!
    @IBOutlet weak var mapView: MGLMapView!
    
    @IBOutlet weak var setLocationButton: UIButton!
    @IBOutlet weak var removeLocationButton: UIButton!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var bottomStackview: UIStackView!
    var locationManager = CLLocationManager()
    
    //  var fetcher1: MGLAu
    var locationArray = NSMutableArray()
    var SelectedCoordination = CLLocationCoordinate2D()
    let dropDown = DropDown()
    var viewType = ""
    var delegate: customLocationDelegate?
    let appDelegete = UIApplication.shared.delegate as! AppDelegate
    var getLocation = ""
    // Location Data
    var city = ""
    var state = ""
    var country = ""
    var countryCode = ""
    var lat = ""
    var long = ""
    var locationString = ""
    var coordinate = CLLocationCoordinate2D()
    let locations = [CLLocation]()
    var regionWillChangeAnimatedCalled = Bool()
    var geocoder: Geocoder!
    var isFromHome = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.configUI()
    }
    func configUI() {
        
        self.navigationController?.isNavigationBarHidden = false
        self.navigationController?.customRightBarButtonView(title: "", fColor: "whitecolor", fontName: UIFont(name: APP_FONT_REGULAR, size: 14), imageName: "detail_back", isLeft: true, vc: self, transparantView: false)
        self.navigationController?.customNavigationBarView(title: "location", fColor: "whitecolor", fontName: UIFont(name: APP_FONT_REGULAR, size: 20), vc: self)
        self.removeLocationButton.setBorder(color: UIColor(named: "AppThemeColorNew"))
        self.setLocationButton.backgroundColor = UIColor(named: "AppThemeColorNew")
        self.setLocationButton.cornerMiniumRadius()
        self.searchView.cornerViewMiniumRadius()
        self.removeLocationButton.config(color: UIColor(named: "AppThemeColorNew"), font: UIFont(name: APP_FONT_REGULAR, size: 15), align: .center, title: "")
        self.setLocationButton.config(color: UIColor(named: "whitecolor"), font: UIFont(name: APP_FONT_REGULAR, size: 15), align: .center, title: "set_location")
        if self.viewType == "chat" {
            self.setLocationButton.setTitle(getLanguage["share_your_location"], for: .normal)
            self.removeLocationButton.isHidden = true
        }
        else if self.viewType == "profile" || self.viewType == "addProduct"{
            self.setLocationButton.setTitle(getLanguage["set_location"], for: .normal)
            self.removeLocationButton.isHidden = true
        }
        
        self.searchTextField.config(color: UIColor(named: "appblackcolor"), align: .left, placeHolder: "search", font: UIFont(name: APP_FONT_REGULAR, size: 14))
        geocoder = Geocoder(accessToken: MAPBOXACCESSTOKEN)
        mapView.attributionButton.isHidden = true
        self.removeLocationButton.setTitle(UserDefaultModule.shared.getcountryname() ?? "", for: .normal)
        self.loadMapView()

//        if #available(iOS 13.0, *) {
//            NotificationCenter.default.addObserver(self, selector: #selector(willEnterForeground), name: UIScene.willEnterForegroundNotification, object: nil)
//        } else {
//            NotificationCenter.default.addObserver(self, selector: #selector(willEnterForeground), name: UIApplication.willEnterForegroundNotification, object: nil)
//        }
        
    }

   
      override var preferredStatusBarStyle : UIStatusBarStyle {
          return self.updateStatusBarStyle()
      }
    
    @objc func willEnterForeground(_ notification: Notification) {
        if !checkLocationPermission() {
            let alertController = UIAlertController(title: getLanguage["alert"] ?? "alert", message: getLanguage["location_permission"] ?? "location_permission", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: getLanguage["ok"] ?? "ok", style: .default, handler: { (UIAlertAction) in
                if let url = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
                }
            }))
            self.present(alertController, animated: true, completion: nil)
        }
        // code to execute
    }
    func loadMapView() {
        self.mapView.isHidden = true
        self.markerButton.isHidden = true
        if checkLocationPermission() {
            self.currentLocationView.darkElevationEffect()
            // self.mapView.isMyLocationEnabled = true
            self.mapView.delegate = self
            locationManager = CLLocationManager()
            locationManager.delegate = self
            self.locationManager.requestWhenInUseAuthorization()
            if self.locationString == "" || self.locationString.lowercased() == "worldwide" || self.locationString.lowercased() == UserDefaultModule.shared.getcountryname()?.lowercased(){
                print("Now in if condition")
                self.locationString = ""
                FILTER_DATA.distance = "\(ADMIN_VIEW_MODEL.adminModel?.result.distance ?? "")"
                self.locationManager.startUpdatingLocation()
            }
            else {
                print("Now in else condition")
                self.searchTextField.text = self.locationString
                self.getLocationFromAddr(self.searchTextField.text!, isSelected: isFromHome)
            }
            
            /*
             fetcher = GMSAutocompleteFetcher.init()
             fetcher?.delegate = self
             session_token = GMSAutocompleteSessionToken.init()
             fetcher?.provide(session_token)
             let fetcherFilter = GMSAutocompleteFilter()
             // MARK: Single Country Personalization
             fetcherFilter.country = "CZ"
             fetcherFilter.type = .city
             fetcher?.autocompleteFilter = fetcherFilter
             //            self.fetcher?.autocompleteFilter?.type = .city
             */
            
            
            
            
            
            //            self.fetcher?.autocompleteFilter?.type = .city
            //            self.fetcher?.autocompleteFilter?.country = "IND"
        }
        else {
            let alertController = UIAlertController(title: getLanguage["alert"] ?? "alert", message: getLanguage["location_permission"] ?? "location_permission", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: getLanguage["ok"] ?? "ok", style: .default, handler: { (UIAlertAction) in
                if let url = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
                }
            }))
            self.present(alertController, animated: true, completion: nil)
        }
    }
    func checkLocationPermission()->Bool {
        var status = false
        if CLLocationManager.locationServicesEnabled() {
            switch CLLocationManager.authorizationStatus() {
            case .notDetermined, .restricted, .denied:
                print("No access")
                self.locationManager.requestWhenInUseAuthorization()
                self.mapView.isHidden = true
                self.markerButton.isHidden = true
            case .authorizedAlways, .authorizedWhenInUse:
                status = true
                self.mapView.isHidden = false
                self.markerButton.isHidden = false
                print("Access")
            @unknown default:
                break
            }
        } else {
            self.locationManager.requestWhenInUseAuthorization()
            print("Location services are not enabled")
        }
        return status
    }

    override func viewWillAppear(_ animated: Bool) {
        self.updateTheme(page: "present")
        NotificationCenter.default.addObserver(self, selector: #selector(self.barButtonAction(_:)), name: Notification.Name("BarButtonAction"), object: nil)
    }
    override func viewWillDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self, name: Notification.Name("BarButtonAction"), object: nil)
    }
    
    @objc func barButtonAction(_ notification: Notification) {
        print(notification)
        if let isLeft = notification.userInfo?["isLeft"] as? Int {
            print(isLeft)
            if isLeft == 1 {
            }
            else {
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    func mapViewRegionIsChanging(_ mapView: MGLMapView) {
        print("Lattitude and longitude: \(mapView.centerCoordinate.latitude)\(mapView.centerCoordinate.longitude)")
        
    }
    
    func mapView(_ mapView: MGLMapView,  regionDidChangeAnimated animated: Bool) {
        
        if "\(mapView.centerCoordinate.longitude)" == "40" {
            regionWillChangeAnimatedCalled = false
            if "\(mapView.centerCoordinate.latitude)" == "\(String(describing: (locationArray.object(at: 0) as AnyObject).floatValue))" {
                regionWillChangeAnimatedCalled = true
            }
        } else {
            regionWillChangeAnimatedCalled = true
        }
        if regionWillChangeAnimatedCalled {
            print("Changing the location: \(mapView.centerCoordinate.latitude) \(mapView.centerCoordinate.longitude)")
            locationArray[0] = "\(mapView.centerCoordinate.latitude)"
            locationArray[1] = "\(mapView.centerCoordinate.longitude)"
            let coordinates = CLLocationCoordinate2D(latitude: mapView.centerCoordinate.latitude, longitude: mapView.centerCoordinate.longitude)
            self.updateLocation(coordinates) { (location) in
                if location != "" {
                    self.searchTextField.text = location
                }
            }
        }
    }
    func updateLocation(_ coordinate: CLLocationCoordinate2D, location: @escaping (String) -> Void) {
        
        let geocoder = GMSGeocoder()
        var locString = ""
        geocoder.reverseGeocodeCoordinate(coordinate) { response , error in
            if let address = response?.firstResult() {
                let lines = address.lines! as [String]
                self.city = address.locality ?? ""
                self.state = address.administrativeArea ?? ""
                self.country = address.country ?? ""
                locString = lines.joined(separator: "\n")
            }
            location(locString)
        }
        
//        var locString = ""
//        let options = ReverseGeocodeOptions(coordinate: coordinate)
//        options.allowedScopes = [.all]
////        options.focalLocation = locationManager.location
//        _ = self.geocoder.geocode(options) { [unowned self] (placemarks, attribution, error) in
//            if let error = error {
//                NSLog("%@", error)
//            } else if let placemarks = placemarks, !placemarks.isEmpty {
////                self.resultsLabel.text = placemarks[0].qualifiedName
//                print("placemarks[0] \(placemarks[0])")
//                print(attribution)
//                self.lat = "\(coordinate.latitude)"
//                self.long = "\(coordinate.longitude)"
//
//                let lines = placemarks[0].address ?? ""
//                self.city = placemarks[0].postalAddress?.city ?? ""
//                self.state = placemarks[0].administrativeRegion?.name ?? ""
//                self.country = placemarks[0].country?.name ?? ""
//                locString = placemarks[0].qualifiedName ?? ""
//                location(locString)
//            } else {
////                self.resultsLabel.text = "No results"
//            }
//        }
    }
    func mapView(_ mapView: MGLMapView, shouldChangeFrom oldCamera: MGLMapCamera, to newCamera: MGLMapCamera) -> Bool {
        
        let loc = CLLocation(latitude: newCamera.centerCoordinate.latitude, longitude: newCamera.centerCoordinate.longitude)
        let locate = CLLocationCoordinate2D(latitude: newCamera.centerCoordinate.latitude, longitude: newCamera.centerCoordinate.longitude)
        //   self.mapView.setCenter(locate, zoomLevel: 14, animated: true)
        print("Location: \(loc)")
        self.updateLocation(locate) { (location) in
            print(location)
            if location != "" {
                self.searchTextField.text = location
            }
//            self.getLocationFromAddr(self.searchTextField.text!)
        }
        return true
    }
    
    @IBAction func currentLocationButtonAct(_ sender: UIButton) {
        self.locationString = ""
        FILTER_DATA.distance = "\(ADMIN_VIEW_MODEL.adminModel?.result.distance ?? "")"
        
        self.locationManager.startUpdatingLocation()
    }
    @IBAction func locationButtonAct(_ sender: UIButton) {
//        solai
        if sender == removeLocationButton {
//            self.locationString = "worldwide"
//            self.lat = ""
//            self.long = ""
             
            // MARK: Single Country Personalization
            self.locationString = UserDefaultModule.shared.getcountryname() ?? ""
            self.lat = ""
            self.long = ""
            self.city = ""
            self.state = ""
            self.country = ""
            self.countryCode = ""
            self.delegate?.locationAct(city: self.city, state: self.state, country: self.country, countryCode:  self.countryCode, lat: self.lat, long: self.long, location: self.locationString)
            self.navigationController?.popViewController(animated: true)
        }
        else {
            print("Latitude check \(lat)")
            print("Longitude check \(long)")
//            if self.lat != "" && self.long != ""
//            {
                print("Country check 1 : \(UserDefaultModule.shared.getcountryname()?.lowercased())")
                print("Country check 2 : \(self.country.lowercased())")
                
                if self.country.lowercased() == UserDefaultModule.shared.getcountryname()?.lowercased() /*||*/ /*self.country.lowercased() == CHECHIA*/ {
                self.delegate?.locationAct(city: self.city, state: self.state, country: self.country, countryCode: self.countryCode, lat: self.lat, long: self.long, location: self.searchTextField.text!)
                self.navigationController?.popViewController(animated: true)
            }
            else {
                let alert = UIAlertController(
                    title: nil,
                    message: (getLanguage["select_location_from_dropdown"] ?? "") + (UserDefaultModule.shared.getcountryname()?.lowercased() ?? ""),
                    preferredStyle: .alert
                )
                alert.addAction(UIAlertAction(title: getLanguage["ok"] ?? "", style: .cancel, handler: nil))
                self.present(alert, animated: true, completion: nil)

            }
//        }
//            else {
//
//                let alert = UIAlertController(title: nil, message: getLanguage["select_location_from_dropdown"] ?? "", preferredStyle: .alert)
//                alert.addAction(UIAlertAction(title: getLanguage["ok"] ?? "", style: .cancel, handler: nil))
//                self.present(alert, animated: true, completion: nil)
//            }
        
    }

    }
}

extension MapViewController: UITextFieldDelegate {
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        self.locationManager.stopUpdatingLocation()
        locationManager.stopMonitoringSignificantLocationChanges()
        self.dropDown.hide()
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.searchForRide(textField: textField)
        print(textField.text!)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        //        textField.resignFirstResponder()
        self.searchForRide(textField: textField)
        return true
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        if string.containsEmoji {
            return false
        }
        self.city = ""
        self.state = ""
        self.country = ""
        self.lat = ""
        self.long = ""
//        fetcher?.sourceTextHasChanged(textField.text!+string)
        self.autoCompletionAct(textField.text!+string)
        return true
        
    }
    func autoCompletionAct(_ text: String) {
        let options = ForwardGeocodeOptions(query: text)
        options.allowedScopes = [.all]
        options.allowedISOCountryCodes = [UserDefaultModule.shared.getcountrycode() ?? "IN"]
//        options.allowedISOCountryCodes = ["\(UserDefaultModule.shared.getcountrycode ?? "IN")"]
        _ = geocoder.geocode(options) { (placemarks, attribution, error) in
            guard let placemark = placemarks else {
                return
            }
            self.locationArray.removeAllObjects()
            for place in placemark {
                let mutableDict = NSMutableDictionary()
                print("prediction value in predictions : \(place)")
                mutableDict.setValue(place.postalAddress?.street ?? "", forKey: "address_first")
                mutableDict.setValue(place.postalAddress?.city, forKey: "address_second")
                mutableDict.setValue(place.code, forKey: "placeID")
                mutableDict.setValue(place.qualifiedName ?? "", forKey: "address_full")
                self.locationArray.addObjects(from: [mutableDict])
            }
            if self.locationArray.count == 0
            {
                self.dropDown.hide()
            }
            else
            {
                self.configDropDownView()
                DispatchQueue.main.async {
                    self.dropDown.show()
                }
            }
        }
    }
    func searchForRide(textField:UITextField)  {
        textField.resignFirstResponder()
    }
}
//MARK: Location auto complete fetcher
extension MapViewController: CLLocationManagerDelegate, MGLMapViewDelegate {

    func mapView(_ mapView: MGLMapView, didSelect annotation: MGLAnnotation) {
        
        let camera = MGLMapCamera(lookingAtCenter: annotation.coordinate, altitude: 4500, pitch: 15, heading: 180)
        mapView.fly(to: camera, withDuration: 4,
                    peakAltitude: 3000, completionHandler: nil)
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations.last!
        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        self.mapView.setCenter(center, zoomLevel: 15, animated: true)

        self.lat = "\(location.coordinate.latitude)"
        self.long = "\(location.coordinate.longitude)"

        self.updateLocation(location.coordinate) { (location) in
            if self.locationString != "" && self.locationString.lowercased() != "worldwide" || self.locationString.lowercased() == UserDefaultModule.shared.getcountryname()?.lowercased() {
                self.searchTextField.text = self.locationString
                self.getLocationFromAddr(self.searchTextField.text!)
            }
            else {
                if self.viewType == "profile" {
                    self.searchTextField.text = "\(self.city), \(self.state), \(self.country)"
                }
                else {
                    self.searchTextField.text = location
                }
            }
            self.mapView.isHidden = false
            self.markerButton.isHidden = false
        }
        
        self.locationManager.stopUpdatingLocation()
    }
    
    func getLocationFromAddr(_ location: String, isSelected: Bool = false) {
        let options = ForwardGeocodeOptions(query: location)
        options.allowedScopes = [.all]
        _ = geocoder.geocode(options) { (placemarks, attribution, error) in
            guard let placemark = placemarks?.first else {
                return
            }
            print("prediction value in predictions : \(placemark)")
            
            self.locationString = self.searchTextField.text!
            if isSelected {
                self.lat = "\(placemark.location?.coordinate.latitude ?? 0)"
                self.long = "\(placemark.location?.coordinate.longitude ?? 0)"
            }
            
            self.city = placemark.postalAddress?.city ?? ""
            self.state = placemark.postalAddress?.state ?? ""
            self.country = placemark.postalAddress?.country ?? ""
            self.locationString = placemark.qualifiedName ?? ""
            self.mapView.isHidden = false
            self.markerButton.isHidden = false
            self.setLocationButton.isUserInteractionEnabled = true
            if !isSelected {
                let center = CLLocationCoordinate2D(latitude: (placemark.location?.coordinate.latitude ?? 0), longitude: (placemark.location?.coordinate.longitude ?? 0))
                self.mapView.setCenter(center, zoomLevel: 15, animated: true)

            }
            else {
                let center = CLLocationCoordinate2D(latitude: (placemark.location?.coordinate.latitude ?? 0), longitude: (placemark.location?.coordinate.longitude ?? 0))
                self.mapView.setCenter(center, zoomLevel: 15, animated: true)

            }

        }
    }
    func configDropDownView() {
        dropDown.anchorView = self.searchView
        dropDown.bottomOffset = CGPoint(x: 0, y:(dropDown.anchorView?.plainView.bounds.height)!)
        dropDown.width = self.searchView.frame.width
        dropDown.semanticContentAttribute = .unspecified
        _ = self.locationArray
        var countryArray = [String]()
        for country in self.locationArray {
            let countryDict = country as! Dictionary<String, Any>
            countryArray.append(countryDict["address_full"] as? String ?? "")
        }
        dropDown.dataSource = countryArray
        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            self.setLocationButton.isUserInteractionEnabled = false
            self.searchTextField.text = item
            self.searchTextField.endEditing(true)
            //            let countryDict = self.locationArray[index] as! Dictionary<String, Any>
            self.getLocationFromAddr(item, isSelected: true)
            print("Selected item: \(item) at index: \(index)")
        }
    }
}


































